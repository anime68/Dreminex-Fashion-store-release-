<?php
/**
 * Plugin Name: Dreminex Native Store App
 * Description: Adds a branded native Android store-app install control and public catalog API without bundling an APK.
 * Version: 0.1.0
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 */

defined('ABSPATH') || exit;

define('DREMINEX_NATIVE_STORE_APP_VERSION', '0.1.0');
define('DREMINEX_NATIVE_STORE_APP_FILE', __FILE__);
define('DREMINEX_NATIVE_STORE_APP_DIR', __DIR__);

require_once __DIR__ . '/includes/class-dreminex-native-store-app.php';

register_activation_hook(__FILE__, ['Dreminex_Native_Store_App', 'activate']);
add_action('plugins_loaded', ['Dreminex_Native_Store_App', 'boot'], 2);
