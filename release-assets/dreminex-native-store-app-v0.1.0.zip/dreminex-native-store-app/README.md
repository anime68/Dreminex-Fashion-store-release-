# Dreminex Native Store App plugin

This lightweight WordPress plugin is the website half of the native customer storefront app.

- It renders the footer `Install Dreminex App` control shown in the Dreminex Fashion mobile layout.
- It stores app name, short name, logo, colors, release channel and trusted GitHub manifest URLs.
- It exposes public catalog/category/branding contracts under `/wp-json/dreminex/v1/store-app/`.
- It creates one signed-APK claim per logged-in WordPress account and returns the existing download on repeat clicks.
- It automatically deactivates the old `dreminex-pwa/dreminex-pwa.php` integration while preserving that plugin's settings and files.
- It never bundles an APK, keystore or password. The release manifest can use the public `Dreminex-Fashion-store-release-` updater schema or a `store_app` object; the plugin normalizes both into the same claim response.

## Repository split

- Native source, tests and design remain in private `anime68/Dreminex-Fashion-store`.
- Signed APK, `update-manifest.json` and checksums are published from public `anime68/Dreminex-Fashion-store-release-`.
- This plugin only points at the public manifest; it does not copy either repository's APK into the WordPress ZIP.

The APK itself is the native Compose project in the private Store repository and has no website install button in its UI.
