(function () {
  'use strict';
  function init() {
    var button = document.getElementById('dnsa-select-logo');
    if (!button || !window.wp || !wp.media || button.dataset.ready === '1') return;
    button.dataset.ready = '1';
    button.addEventListener('click', function () {
      var frame = wp.media({ title: 'Choose app logo', button: { text: 'Use this logo' }, multiple: false, library: { type: 'image' } });
      frame.on('select', function () {
        var item = frame.state().get('selection').first().toJSON();
        var id = document.getElementById('dnsa-logo-id');
        var url = document.getElementById('dnsa-logo-url');
        if (id) id.value = item.id || '';
        if (url) url.value = item.url || '';
      });
      frame.open();
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  window.setTimeout(init, 250);
}());
