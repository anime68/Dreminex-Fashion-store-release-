(function () {
  'use strict';
  var cfg = window.DreminexNativeStoreApp || {};
  var buttons = document.querySelectorAll('[data-dreminex-native-store-install]');
  if (!buttons.length) return;
  function setState(button, message, state) {
    var status = button.closest('.dreminex-native-store-footer, .dreminex-native-store-inline');
    status = status && status.querySelector('.dreminex-native-store-status');
    if (status) status.textContent = message || '';
    if (state) button.setAttribute('data-state', state); else button.removeAttribute('data-state');
    button.disabled = state === 'busy';
  }
  function claim(button) {
    if (!cfg.restUrl) { setState(button, 'App installation is not configured yet.', 'error'); return; }
    setState(button, 'Checking your account…', 'busy');
    fetch(String(cfg.restUrl).replace(/\/$/, '') + '/claim', { method: 'POST', credentials: 'same-origin', headers: { 'X-WP-Nonce': cfg.nonce || '', 'Accept': 'application/json' } })
      .then(function (response) {
        if (response.status === 401 || response.status === 403) { window.location.href = cfg.loginUrl || '/wp-login.php'; return null; }
        return response.json().then(function (body) { return { ok: response.ok, body: body }; });
      })
      .then(function (result) {
        if (!result) return;
        var claimData = result.body && result.body.claim;
        if (!result.ok || !claimData || !claimData.download_url) { throw new Error(result.body && result.body.message ? result.body.message : 'A signed release is not ready yet.'); }
        setState(button, result.body.already_claimed ? 'Your existing app download is ready.' : 'Your app download is ready.', 'done');
        window.location.assign(claimData.download_url);
      })
      .catch(function (error) { setState(button, error.message || 'Could not prepare the app download.', 'error'); });
  }
  Array.prototype.forEach.call(buttons, function (button) { button.addEventListener('click', function () { claim(button); }); });
}());
