<?php
/**
 * Native customer storefront app bridge.
 *
 * The plugin owns configuration and public API contracts only. APK bytes and
 * signing material stay in the GitHub release repository.
 */

defined('ABSPATH') || exit;

final class Dreminex_Native_Store_App {
    const OPTION = 'dreminex_native_store_app_settings';
    const TRANSITION_OPTION = 'dreminex_native_store_app_pwa_transition';
    const CLAIM_META = 'dreminex_native_store_app_claim';
    const MANIFEST_TRANSIENT = 'dreminex_native_store_app_release_manifest';
    const NS = 'dreminex/v1';
    const DEFAULT_MANIFEST = 'https://github.com/anime68/Dreminex-Fashion-store-release-/releases/latest/download/update-manifest.json';

    public static function defaults() {
        return [
            'enabled' => 1,
            'app_name' => 'Dreminex Fashion',
            'short_name' => 'Dreminex',
            'logo_url' => '',
            'logo_id' => 0,
            'theme_color' => '#08B6D3',
            'background_color' => '#FFFFFF',
            'footer_button' => 1,
            'button_label' => 'Install Dreminex App',
            'release_channel' => 'production',
            'production_manifest_url' => self::DEFAULT_MANIFEST,
            'staging_manifest_url' => '',
            'manifest_url' => self::DEFAULT_MANIFEST,
            'push_enabled' => 1,
            'catalog_per_page' => 24,
            'claim_enabled' => 1,
        ];
    }

    public static function settings() {
        return wp_parse_args((array) get_option(self::OPTION, []), self::defaults());
    }

    public static function activate() {
        if (!get_option(self::OPTION, false)) {
            add_option(self::OPTION, self::defaults(), '', false);
        }
        self::retire_pwa(true);
    }

    public static function boot() {
        self::retire_pwa(false);
        add_action('init', [__CLASS__, 'register_shortcodes']);
        add_action('rest_api_init', [__CLASS__, 'register_routes']);
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_frontend']);
        add_action('wp_footer', [__CLASS__, 'render_footer'], 18);
        add_action('admin_init', [__CLASS__, 'register_settings']);
        add_action('admin_menu', [__CLASS__, 'admin_menu']);
        add_action('admin_notices', [__CLASS__, 'admin_notice']);
    }

    /**
     * Retire the old PWA integration without removing its settings or files.
     * It runs on activation and on the next request so an old active PWA cannot
     * compete with the native installer.
     */
    public static function retire_pwa($activation = false) {
        if (!function_exists('deactivate_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        if (!function_exists('deactivate_plugins')) {
            return;
        }
        $active = (array) get_option('active_plugins', []);
        $network = (array) get_site_option('active_sitewide_plugins', []);
        $matches = [];
        foreach (array_unique(array_merge($active, array_keys($network))) as $plugin) {
            $normalized = strtolower((string) $plugin);
            if ($normalized === 'dreminex-pwa/dreminex-pwa.php' || strpos($normalized, 'dreminex-pwa') !== false) {
                $matches[] = $plugin;
            }
        }
        if (!$matches) {
            self::remove_loaded_pwa_hooks();
            return;
        }
        $network_matches = array_values(array_filter($matches, static function ($plugin) use ($network) {
            return isset($network[$plugin]);
        }));
        $site_matches = array_values(array_diff($matches, $network_matches));
        if ($network_matches) {
            deactivate_plugins($network_matches, true);
        }
        if ($site_matches) {
            deactivate_plugins($site_matches, false);
        }
        self::remove_loaded_pwa_hooks();
        update_option(self::TRANSITION_OPTION, [
            'at' => gmdate('c'),
            'plugins' => array_values($matches),
            'activation' => (bool) $activation,
            'data_preserved' => true,
        ], false);
    }

    private static function remove_loaded_pwa_hooks() {
        if (!class_exists('Dreminex_PWA')) {
            return;
        }
        remove_action('init', ['Dreminex_PWA', 'endpoint'], -100);
        remove_action('wp_enqueue_scripts', ['Dreminex_PWA', 'frontend']);
        remove_action('wp_head', ['Dreminex_PWA', 'head']);
        remove_action('wp_footer', ['Dreminex_PWA', 'footer'], 15);
    }

    public static function register_shortcodes() {
        add_shortcode('dreminex_native_store_install', [__CLASS__, 'shortcode']);
    }

    public static function enqueue_frontend() {
        if (is_admin() || is_feed()) {
            return;
        }
        $s = self::settings();
        if (empty($s['enabled']) || empty($s['footer_button'])) {
            return;
        }
        wp_enqueue_style('dreminex-native-store-app', plugins_url('assets/store-app.css', DREMINEX_NATIVE_STORE_APP_FILE), [], DREMINEX_NATIVE_STORE_APP_VERSION);
        wp_enqueue_script('dreminex-native-store-app', plugins_url('assets/store-app.js', DREMINEX_NATIVE_STORE_APP_FILE), [], DREMINEX_NATIVE_STORE_APP_VERSION, true);
        wp_localize_script('dreminex-native-store-app', 'DreminexNativeStoreApp', [
            'restUrl' => esc_url_raw(rest_url(self::NS . '/store-app/')),
            'nonce' => wp_create_nonce('wp_rest'),
            'loginUrl' => wp_login_url(self::current_url()),
            'enabled' => true,
            'label' => (string) $s['button_label'],
        ]);
    }

    public static function current_url() {
        $scheme = is_ssl() ? 'https://' : 'http://';
        $host = isset($_SERVER['HTTP_HOST']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_HOST'])) : wp_parse_url(home_url('/'), PHP_URL_HOST);
        $request = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '/';
        return esc_url_raw($scheme . $host . $request);
    }

    public static function render_footer() {
        if (is_admin() || is_feed() || (function_exists('is_checkout') && is_checkout())) {
            return;
        }
        $s = self::settings();
        if (empty($s['enabled']) || empty($s['footer_button'])) {
            return;
        }
        echo self::button_markup();
    }

    public static function shortcode() {
        $s = self::settings();
        return !empty($s['enabled']) && !empty($s['footer_button']) ? self::button_markup(false) : '';
    }

    private static function button_markup($wrap = true) {
        $s = self::settings();
        $logo = self::logo_url($s);
        $inner = '<div class="dreminex-native-store-brand">' . ($logo ? '<img src="' . esc_url($logo) . '" alt="' . esc_attr($s['app_name']) . '" loading="lazy">' : '<span>' . esc_html($s['app_name']) . '</span>') . '</div>';
        $inner .= '<button type="button" class="dreminex-native-store-install" data-dreminex-native-store-install aria-describedby="dreminex-native-store-status"><span class="dreminex-native-store-install-label">' . esc_html($s['button_label']) . '</span><span class="dreminex-native-store-install-state" aria-hidden="true"></span></button>';
        $inner .= '<p id="dreminex-native-store-status" class="dreminex-native-store-status" role="status" aria-live="polite"></p>';
        return $wrap ? '<section class="dreminex-native-store-footer" aria-label="' . esc_attr($s['app_name']) . ' app"><div class="dreminex-native-store-footer-inner">' . $inner . '</div></section>' : '<div class="dreminex-native-store-inline">' . $inner . '</div>';
    }

    private static function logo_url($s) {
        if (!empty($s['logo_id'])) {
            $url = wp_get_attachment_image_url((int) $s['logo_id'], 'medium');
            if ($url) {
                return $url;
            }
        }
        if (!empty($s['logo_url'])) {
            return esc_url_raw($s['logo_url']);
        }
        return get_site_icon_url(192);
    }

    public static function register_settings() {
        register_setting('dreminex_native_store_app', self::OPTION, [
            'type' => 'array',
            'sanitize_callback' => [__CLASS__, 'sanitize_settings'],
            'default' => self::defaults(),
        ]);
    }

    public static function sanitize_settings($input) {
        $old = self::settings();
        $out = self::defaults();
        foreach (['enabled', 'footer_button', 'push_enabled', 'claim_enabled'] as $key) {
            $out[$key] = empty($input[$key]) ? 0 : 1;
        }
        foreach (['app_name', 'short_name', 'button_label', 'logo_url', 'manifest_url', 'production_manifest_url', 'staging_manifest_url'] as $key) {
            $value = sanitize_text_field($input[$key] ?? $old[$key]);
            if (in_array($key, ['manifest_url', 'production_manifest_url', 'staging_manifest_url'], true) && $value !== '' && !self::trusted_release_url($value)) {
                $value = $old[$key];
            }
            $out[$key] = $value !== '' ? $value : $old[$key];
        }
        $out['logo_id'] = absint($input['logo_id'] ?? $old['logo_id']);
        foreach (['theme_color', 'background_color'] as $key) {
            $out[$key] = sanitize_hex_color($input[$key] ?? '') ?: $old[$key];
        }
        $out['release_channel'] = in_array(($input['release_channel'] ?? ''), ['production', 'staging'], true) ? $input['release_channel'] : $old['release_channel'];
        $out['catalog_per_page'] = max(1, min(48, absint($input['catalog_per_page'] ?? $old['catalog_per_page'])));
        return $out;
    }

    public static function admin_menu() {
        add_options_page('Dreminex Native Store App', 'Native Store App', 'manage_options', 'dreminex-native-store-app', [__CLASS__, 'admin_page']);
    }

    public static function admin_notice() {
        if (!current_user_can('manage_options') || !isset($_GET['page']) || $_GET['page'] !== 'dreminex-native-store-app') {
            return;
        }
        $transition = get_option(self::TRANSITION_OPTION, []);
        if (!empty($transition['plugins'])) {
            echo '<div class="notice notice-info"><p>Dreminex Native Store App disabled the old PWA integration without deleting its settings or data: ' . esc_html(implode(', ', (array) $transition['plugins'])) . '.</p></div>';
        }
    }

    public static function admin_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $s = self::settings();
        $manifest = self::release_manifest(true);
        $transition = get_option(self::TRANSITION_OPTION, []);
        wp_enqueue_media();
        ?>
        <div class="wrap">
            <h1>Dreminex Native Store App</h1>
            <p>এই plugin-এ APK রাখা হয় না। GitHub release manifest থেকে signed APK-এর URL, SHA-256 এবং version পড়ে install/update হয়।</p>
            <form method="post" action="options.php">
                <?php settings_fields('dreminex_native_store_app'); ?>
                <table class="form-table" role="presentation">
                    <?php self::checkbox_row('enabled', 'Enable native store app', $s); ?>
                    <?php self::checkbox_row('footer_button', 'Show footer Install App button', $s); ?>
                    <?php self::checkbox_row('push_enabled', 'Enable app notification registration', $s); ?>
                    <?php self::checkbox_row('claim_enabled', 'Allow one install claim per account', $s); ?>
                    <?php self::text_row('app_name', 'App name', $s); ?>
                    <?php self::text_row('short_name', 'Short name', $s); ?>
                    <tr><th><label for="dnsa-logo-url">Logo</label></th><td><input id="dnsa-logo-url" class="regular-text" name="<?php echo esc_attr(self::OPTION); ?>[logo_url]" value="<?php echo esc_attr($s['logo_url']); ?>"><input type="hidden" id="dnsa-logo-id" name="<?php echo esc_attr(self::OPTION); ?>[logo_id]" value="<?php echo esc_attr($s['logo_id']); ?>"><button type="button" class="button" id="dnsa-select-logo">Choose from Media</button><p class="description">A square blue/gold Dreminex mark works best for the launcher. The APK is still not stored here.</p></td></tr>
                    <?php self::text_row('button_label', 'Footer button text', $s); ?>
                    <?php self::text_row('theme_color', 'Theme color', $s); ?>
                    <?php self::text_row('background_color', 'Splash background', $s); ?>
                    <tr><th><label for="dnsa-release-channel">Release channel</label></th><td><select id="dnsa-release-channel" name="<?php echo esc_attr(self::OPTION); ?>[release_channel]"><option value="production" <?php selected($s['release_channel'], 'production'); ?>>Production</option><option value="staging" <?php selected($s['release_channel'], 'staging'); ?>>Staging</option></select></td></tr>
                    <?php self::text_row('production_manifest_url', 'Production GitHub manifest URL', $s); ?>
                    <?php self::text_row('staging_manifest_url', 'Staging GitHub manifest URL (optional)', $s); ?>
                    <tr><th><label for="dnsa-catalog-per-page">Catalog items per request</label></th><td><input id="dnsa-catalog-per-page" type="number" min="1" max="48" name="<?php echo esc_attr(self::OPTION); ?>[catalog_per_page]" value="<?php echo esc_attr($s['catalog_per_page']); ?>"></td></tr>
                </table>
                <?php submit_button('Save Native App Settings'); ?>
            </form>
            <h2>Release read-back</h2>
            <p>Selected manifest URL: <code><?php echo esc_html(self::selected_manifest_url($s)); ?></code></p>
            <?php if (!empty($manifest['store_app'])) : ?>
                <p><strong>Customer app:</strong> <?php echo esc_html($manifest['store_app']['version'] ?? 'unknown'); ?> · checksum <?php echo !empty($manifest['store_app']['sha256']) ? 'present' : 'missing'; ?></p>
            <?php else : ?>
                <p class="notice notice-warning inline">No customer app release is available in the configured manifest yet. Publish a <code>store_app</code> asset before enabling installs.</p>
            <?php endif; ?>
            <h2>Compatibility</h2>
            <ul><li>Old PWA data is preserved; its plugin is disabled automatically when this plugin is activated.</li><li>Customer APK is native Compose UI and never renders an install button.</li><li>Brand name/logo changes are delivered by manifest when possible; launcher icon/name changes require a new signed APK.</li></ul>
            <?php if (!empty($transition['at'])) : ?><p>Last PWA transition: <?php echo esc_html($transition['at']); ?>. Data preserved: <?php echo !empty($transition['data_preserved']) ? 'yes' : 'unknown'; ?>.</p><?php endif; ?>
        </div>
        <script>(function(){var b=document.getElementById('dnsa-select-logo');if(!b||typeof wp==='undefined'||!wp.media)return;b.addEventListener('click',function(){var f=wp.media({title:'Choose app logo',button:{text:'Use this logo'},multiple:false,library:{type:'image'}});f.on('select',function(){var a=f.state().get('selection').first().toJSON();document.getElementById('dnsa-logo-id').value=a.id||'';document.getElementById('dnsa-logo-url').value=a.url||'';});f.open();});}());</script>
        <?php
    }

    private static function checkbox_row($key, $label, $s) {
        echo '<tr><th>' . esc_html($label) . '</th><td><label><input type="checkbox" name="' . esc_attr(self::OPTION) . '[' . esc_attr($key) . ']" value="1" ' . checked(!empty($s[$key]), true, false) . '> On</label></td></tr>';
    }

    private static function text_row($key, $label, $s) {
        echo '<tr><th><label for="dnsa-' . esc_attr($key) . '">' . esc_html($label) . '</label></th><td><input id="dnsa-' . esc_attr($key) . '" class="regular-text" name="' . esc_attr(self::OPTION) . '[' . esc_attr($key) . ']" value="' . esc_attr($s[$key]) . '"></td></tr>';
    }

    public static function register_routes() {
        register_rest_route(self::NS, '/store-app/manifest', ['methods' => WP_REST_Server::READABLE, 'permission_callback' => '__return_true', 'callback' => [__CLASS__, 'manifest_endpoint']]);
        register_rest_route(self::NS, '/store-app/catalog', ['methods' => WP_REST_Server::READABLE, 'permission_callback' => '__return_true', 'callback' => [__CLASS__, 'catalog_endpoint']]);
        register_rest_route(self::NS, '/store-app/categories', ['methods' => WP_REST_Server::READABLE, 'permission_callback' => '__return_true', 'callback' => [__CLASS__, 'categories_endpoint']]);
        register_rest_route(self::NS, '/store-app/claim', ['methods' => WP_REST_Server::CREATABLE, 'permission_callback' => static function () { return is_user_logged_in(); }, 'callback' => [__CLASS__, 'claim_endpoint']]);
        register_rest_route(self::NS, '/store-app/health', ['methods' => WP_REST_Server::READABLE, 'permission_callback' => '__return_true', 'callback' => [__CLASS__, 'health_endpoint']]);
    }

    public static function manifest_endpoint() {
        $s = self::settings();
        $release = self::release_manifest();
        return rest_ensure_response([
            'site_id' => md5(home_url('/')),
            'site_url' => home_url('/'),
            'site_name' => get_bloginfo('name'),
            'branding' => [
                'name' => (string) $s['app_name'],
                'short_name' => (string) $s['short_name'],
                'logo_url' => self::logo_url($s),
                'theme_color' => (string) $s['theme_color'],
                'background_color' => (string) $s['background_color'],
            ],
            'features' => ['catalog' => true, 'offers' => true, 'bundles' => true, 'push' => !empty($s['push_enabled']), 'claim_once' => !empty($s['claim_enabled'])],
            'release_channel' => (string) $s['release_channel'],
            'store_app' => self::public_release($release),
            'server_time' => gmdate('c'),
        ]);
    }

    public static function health_endpoint() {
        return rest_ensure_response(['ok' => true, 'woocommerce' => class_exists('WooCommerce'), 'https' => is_ssl(), 'version' => DREMINEX_NATIVE_STORE_APP_VERSION]);
    }

    private static function trusted_release_url($url) {
        $url = esc_url_raw((string) $url);
        if ($url === '' || strpos($url, 'https://') !== 0) {
            return false;
        }
        $host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));
        return in_array($host, ['github.com', 'raw.githubusercontent.com', 'objects.githubusercontent.com', 'github-releases.githubusercontent.com'], true);
    }

    private static function public_release($manifest) {
        $release = isset($manifest['store_app']) && is_array($manifest['store_app']) ? $manifest['store_app'] : [];
        return [
            'version' => sanitize_text_field($release['version'] ?? ''),
            'download_url' => self::trusted_release_url($release['download_url'] ?? '') ? esc_url_raw($release['download_url']) : '',
            'sha256' => preg_match('/^[a-f0-9]{64}$/i', (string) ($release['sha256'] ?? '')) ? strtolower((string) $release['sha256']) : '',
            'release_notes_url' => self::trusted_release_url($release['release_notes_url'] ?? '') ? esc_url_raw($release['release_notes_url']) : '',
            'published_at' => sanitize_text_field($release['published_at'] ?? ''),
        ];
    }

    public static function catalog_endpoint(WP_REST_Request $request) {
        if (!function_exists('wc_get_products')) {
            return new WP_Error('woocommerce_unavailable', 'WooCommerce is required for the public catalog.', ['status' => 503]);
        }
        $s = self::settings();
        $per_page = max(1, min(48, (int) ($request->get_param('per_page') ?: $s['catalog_per_page'])));
        $page = max(1, (int) ($request->get_param('page') ?: 1));
        $args = ['status' => 'publish', 'limit' => $per_page, 'page' => $page, 'paginate' => true, 'return' => 'objects', 'orderby' => 'date', 'order' => 'DESC'];
        $search = sanitize_text_field((string) $request->get_param('search'));
        $category = sanitize_title((string) $request->get_param('category'));
        $orderby = sanitize_key((string) $request->get_param('orderby'));
        if ($search !== '') { $args['s'] = $search; }
        if ($category !== '') { $args['category'] = [$category]; }
        if (in_array($orderby, ['date', 'title', 'price', 'popularity', 'rating'], true)) { $args['orderby'] = $orderby; }
        $result = wc_get_products($args);
        $products = is_object($result) && isset($result->products) ? $result->products : (array) $result;
        $total = is_object($result) && isset($result->total) ? (int) $result->total : count($products);
        $pages = is_object($result) && isset($result->max_num_pages) ? (int) $result->max_num_pages : (int) ceil($total / $per_page);
        $items = array_map([__CLASS__, 'serialize_product'], $products);
        return rest_ensure_response(['items' => array_values(array_filter($items)), 'page' => $page, 'per_page' => $per_page, 'total' => $total, 'pages' => $pages, 'modified_at' => gmdate('c')]);
    }

    private static function serialize_product($product) {
        if (!is_object($product) || !is_a($product, 'WC_Product')) { return null; }
        $images = [];
        $ids = array_filter(array_merge([$product->get_image_id()], $product->get_gallery_image_ids()));
        foreach ($ids as $id) { $url = wp_get_attachment_image_url((int) $id, 'woocommerce_thumbnail'); if ($url) { $images[] = esc_url_raw($url); } }
        $categories = [];
        foreach ($product->get_category_ids() as $term_id) { $term = get_term($term_id, 'product_cat'); if ($term && !is_wp_error($term)) { $categories[] = ['id' => (int) $term->term_id, 'name' => $term->name, 'slug' => $term->slug]; } }
        return [
            'id' => $product->get_id(), 'name' => $product->get_name(), 'slug' => $product->get_slug(), 'permalink' => $product->get_permalink(),
            'description' => wp_strip_all_tags($product->get_short_description() ?: $product->get_description()), 'images' => $images, 'categories' => $categories,
            'type' => $product->get_type(), 'sku' => $product->get_sku(), 'currency' => get_woocommerce_currency(), 'price' => (string) $product->get_price(),
            'regular_price' => (string) $product->get_regular_price(), 'sale_price' => (string) $product->get_sale_price(), 'on_sale' => $product->is_on_sale(),
            'stock_status' => $product->get_stock_status(), 'in_stock' => $product->is_in_stock(), 'average_rating' => $product->get_average_rating(),
            'review_count' => $product->get_review_count(), 'modified' => get_post_modified_time('c', true, $product->get_id()),
        ];
    }

    public static function categories_endpoint() {
        $terms = get_terms(['taxonomy' => 'product_cat', 'hide_empty' => true, 'number' => 100]);
        if (is_wp_error($terms)) { return new WP_Error('categories_unavailable', $terms->get_error_message(), ['status' => 503]); }
        return rest_ensure_response(array_map(static function ($term) {
            $thumbnail_id = (int) get_term_meta($term->term_id, 'thumbnail_id', true);
            return ['id' => (int) $term->term_id, 'name' => $term->name, 'slug' => $term->slug, 'count' => (int) $term->count, 'image' => $thumbnail_id ? esc_url_raw((string) wp_get_attachment_image_url($thumbnail_id, 'thumbnail')) : ''];
        }, $terms));
    }

    public static function claim_endpoint() {
        $s = self::settings();
        if (empty($s['claim_enabled'])) { return new WP_Error('claim_disabled', 'Install claims are disabled for this site.', ['status' => 409]); }
        $user_id = get_current_user_id();
        $existing = get_user_meta($user_id, self::CLAIM_META, true);
        if (is_array($existing) && !empty($existing['download_url'])) {
            return rest_ensure_response(['claimed' => true, 'already_claimed' => true, 'claim' => $existing]);
        }
        $release = self::public_release(self::release_manifest());
        if (empty($release['download_url']) || empty($release['version']) || !preg_match('/^[a-f0-9]{64}$/i', (string) $release['sha256'])) { return new WP_Error('release_unavailable', 'A signed customer app release with a checksum is not configured yet.', ['status' => 503]); }
        $claim = ['claimed_at' => gmdate('c'), 'version' => $release['version'], 'download_url' => $release['download_url'], 'sha256' => $release['sha256'], 'site_id' => md5(home_url('/'))];
        update_user_meta($user_id, self::CLAIM_META, $claim);
        return new WP_REST_Response(['claimed' => true, 'already_claimed' => false, 'claim' => $claim], 201);
    }

    private static function selected_manifest_url($settings) {
        if (($settings['release_channel'] ?? 'production') === 'staging' && !empty($settings['staging_manifest_url']) && self::trusted_release_url($settings['staging_manifest_url'])) {
            return esc_url_raw($settings['staging_manifest_url']);
        }
        if (!empty($settings['production_manifest_url']) && self::trusted_release_url($settings['production_manifest_url'])) {
            return esc_url_raw($settings['production_manifest_url']);
        }
        return self::trusted_release_url($settings['manifest_url'] ?? '') ? esc_url_raw($settings['manifest_url']) : '';
    }

    public static function release_manifest($force = false) {
        $s = self::settings();
        if (!$force) {
            $cached = get_transient(self::MANIFEST_TRANSIENT);
            if (is_array($cached)) { return $cached; }
        }
        $url = self::selected_manifest_url($s);
        if ($url === '') { return []; }
        $response = wp_remote_get($url, ['timeout' => 8, 'redirection' => 3, 'headers' => ['Accept' => 'application/json']]);
        if (is_wp_error($response) || 200 !== (int) wp_remote_retrieve_response_code($response)) { return []; }
        $data = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($data)) { return []; }
        if (empty($data['store_app']) && !empty($data['version_name']) && !empty($data['apk']) && is_array($data['apk'])) {
            $data['store_app'] = [
                'version' => sanitize_text_field($data['version_name']),
                'download_url' => esc_url_raw($data['apk']['browser_download_url'] ?? ''),
                'sha256' => strtolower((string) ($data['apk']['sha256'] ?? '')),
                'release_notes_url' => '',
                'published_at' => sanitize_text_field($data['published_at'] ?? ''),
            ];
        }
        $store = isset($data['store_app']) && is_array($data['store_app']) ? $data['store_app'] : [];
        if (!empty($store['download_url']) && !self::trusted_release_url($store['download_url'])) { $data['store_app']['download_url'] = ''; }
        set_transient(self::MANIFEST_TRANSIENT, $data, 5 * MINUTE_IN_SECONDS);
        return $data;
    }
}
